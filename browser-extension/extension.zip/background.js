console.log("started")

console.log(document)
